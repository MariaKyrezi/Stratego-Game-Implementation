package controller;

import model.board.Board;
import model.piece.Piece;
import model.piece.RestrictedArea;
import model.player.BluePlayer;
import model.player.Player;
import model.player.RedPlayer;

import javax.swing.*;
import java.util.ArrayList;

public class Controller {

    private ArrayList <Player> players;
    int round=0;
    Piece[][] boardController =  new Piece[8][10];
    Board board;

    /** <b>constructor</b>: Constructs a new Controller and sets the game as
     * ready to start .
     * <b>postcondition</b>: constructs a new Controller,with 2 new players and the board of the game
     * with the pieces in specific places.So,is responsible for creating a new game and
     * initializing it.
     */
    public Controller(){
        board = new Board();
        initPlayers();
        initBoard();
        this.players.get(0).Played();
    }

    /**
     * Method that returns the players of the game in a list
     * @return a list with the players of the game
     */
    public ArrayList<Player> getPlayers(){
        return this.players;
    }

    /**
     * Method that makes a board with the random pieces of each player on each side , incuding the Restricted areas, and returns it.
     * <p><b>Postcondition:</b>  returns the board of the game initialized with the needed pieces </p>
     *
     * @return the board with pieces
     */
    public Piece[][] getBoard()
    {
        for(int i=0;i<8;i++){
            for(int j=0;j<10;j++){
                if(i<=2){
                    boardController[i][j]=this.players.get(0).returnRandomPiece();
                    boardController[i][j].setX(i);
                    boardController[i][j].setY(j);
                    boardController[i][j].setColour("Red");
                }else if(i>=5){
                    boardController[i][j]=this.players.get(1).returnRandomPiece();
                    boardController[i][j].setX(i);
                    boardController[i][j].setY(j);
                    boardController[i][j].setColour("blue");
                }else if((i == 3 && j==2)||(i == 3 && j==3)||(i == 3 && j==6)||(i == 3 && j==7)||(i == 4 && j==2)||(i == 4 && j==3)||(i == 4 && j==6)||(i == 4 && j==7)){
                    boardController[i][j]=new RestrictedArea();
                    boardController[i][j].setX(i);
                    boardController[i][j].setY(j);
                }else{
                    boardController[i][j]=null;
                }
            }
        }
        return boardController;
    }

    /**
     * Method that initializes the board of the game
     */
    public void initBoard(){
        board.putPiecesOnBoard(getBoard());
    }
    /**
     * <b>transformer(mutative)</b>: initializes players and stores them in an arraylist
     * <p><b>Postcondition:</b> initializes players for the start of the game </p>
     */
    public void initPlayers()
    {
        players=new ArrayList<Player>(2);
        Player Red = new RedPlayer();
        Player Blue = new BluePlayer();
        players.add(Red);
        players.add(Blue);
    }

    /**
     * Method that returns the piece with exact x,y coordinates from the board
     * @param x is the x coordinate of the piece
     * @param y is the y coordinate of the piece
     * @return the piece in the exact (x,y) coordinates
     */
    public Piece returnBoardPiece(int x, int y){
        return board.returnPiece(x,y);
    }

    /**
     * Method that returns a copy of the board when first initialized
     * @return a copy of the board when first initialized
     */
    public Piece[][] getBoardController(){
        return board.getBoard();
    }

    /**
     * Method that sets which player has played
     * @param colour is the colour of the player that played
     */
    public void switchTurn(String colour){
        if(colour=="blue"){
            players.get(1).checkTurn();
        }else{
            players.get(0).checkTurn();
        }

    }
    /**
     * Method that when called it increases the number of round.
     * In the game the method is called everytime the red player plays because he starts playing first.
     */
    public void increaseRound(){
        this.round++;
    }

    /**
     * Method that returns the number of the round in the game
     * <p><b>Postcondition:</b> returns the number of the round </p>
     * @return the round of the game
     */
    public int GetRound()
    {
        return this.round;
    }

    /**
     * Method that announces the winner of the game deciding between the blue and red player
     * <p><b>Postcondition:</b> a message with the winning player pops up </p>
     * @param colour is the colour of the player that wins
     */
    public void winner(String colour){
        if(colour=="blue"){
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "YOU ARE THE BEST!!!", "Blue Player wins!!!!!" , JOptionPane.PLAIN_MESSAGE);
        }else{
            JFrame jFrame = new JFrame();
            JOptionPane.showMessageDialog(jFrame, "YOU ARE THE BEST!!!", "Red Player wins!!!!!", JOptionPane.PLAIN_MESSAGE);
        }
    }

}

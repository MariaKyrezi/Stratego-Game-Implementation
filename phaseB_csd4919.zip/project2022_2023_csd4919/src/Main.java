import controller.Controller;
import view.View;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        View view = new View(); // create window (jframe)
        view.setSize(1250, 700);
        view.setVisible(true);
    }
}

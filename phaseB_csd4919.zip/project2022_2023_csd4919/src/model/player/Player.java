package model.player;

import model.piece.Piece;
import java.util.ArrayList;

public abstract interface Player {

    /**
     * Method that sets the name of the player
     * @param name the name of the player
     */
     public void setName(String name);

    /**
     * Method that returns the name of the player
     * @return the name of the player
     */
     public String getName();

    /**
     * Method that changes the turn of the player
     */
     public void checkTurn();

    /**
     * <b>transformer(mutative)</b>: sets the collection of pieces that the player wants to play with
     * <p><b>Post-condition:</b> The collection of pieces of this player are being set</p>
     */
    public void setPiecesforplaying();

    /**
     * Method that increases the successful attacks by one
     */
    public void countAttacks();

    /**
     * Method that returns the number of opponent's killed pieces
     * @return the number of the opponent's killed pieces
     */
    public int getKilledPieces();
    /**
     * Method that adds a killed piece in an Arraylist that will contain all the killed pieces of the opponent
     * @param piece is the killed piece after an attack
     */
    public void addKilledPieceInList(Piece piece);

    /**
     * Accessor(selector) : Returns an arraylist with the pieces of the player
     * @return the coolection of pieces that the player has
     */
    public ArrayList<Piece> getPiecesForPlaying();

    /**
     * <b>transformer(mutative)</b>: sets the variable hasplayed to true
     * <p><b>Postcondition:</b>  sets the variable hasplayed to true</p>
     */
    public void Played();

    /**
     * Method that removes the killed piece from the collection of pieces that the player has
     * @param piece is the piece removed from the player's pieces for playing
     */
    public void removePiece(Piece piece);

    /**
     * Method that returns an Arrayloist with all the killed pieces of the opponent
     * @return the arraylist with all the killed pieces of the opponent
     */
    public ArrayList<Piece> getTotalKilledPieces();

    /**
     * Method that returns the number of attacks the player has done
     * @return the total successfull attacks
     */
    public double getSuccessfullAttacks();

    /**
     * Method that returns a random piece from the player's pieces for playing but one time each... The method can not return the same piece
     * @return a unique random piece from the player's pieces for playing
     */
    public Piece returnRandomPiece();

}

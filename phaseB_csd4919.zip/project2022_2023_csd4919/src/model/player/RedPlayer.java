package model.player;


import controller.Controller;
import model.piece.*;
import view.View;

import java.util.ArrayList;

public class RedPlayer implements Player{

    private String name;
    private int TotalSaves=0,Attacks=0;
    private boolean has_played;
    ArrayList<Piece> piecesforplaying,tempPieces=new ArrayList<>(30);
    public ArrayList<Piece> killedPieces;
    public int numberOfKilledPieces=0;

    /**
     * Constructor: Makes a new Red player with already initialized the name and the pieces for playing
     */
    public RedPlayer(){
        this.has_played=false;
        this.piecesforplaying=new ArrayList<Piece>(30);
        setPiecesforplaying();
        setName("Volcandria");
        killedPieces= new ArrayList<>();
    }

    /**
     * Method that removes the particular piece from the player's pieces for playing
     * @param piece is the piece removed from the player's pieces for playing
     */
    @Override
    public void removePiece(Piece piece){
        this.piecesforplaying.remove(piece);
    }

    /**
     * Method that adds the particular piece in the Arraylist of killed Pieces of the player
     * @param piece is the killed piece after an attack
     */
    @Override
    public void addKilledPieceInList(Piece piece){
        this.killedPieces.add(piece);
        numberOfKilledPieces++;
    }

    /**
     * Method that returns the number of pieces saved by the player
     * @return the number of pieces saved
     */
    public int getTotalSaves(){
        return this.TotalSaves;
    }

    /**
     * Method that counts the total saves of the player.
     * The total is being counted by adding the total of saves of each piece the player has in his collection.
     */

    public void countTotalSaves(){
        TotalSaves++;
    }
    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return this.name;
    }
    @Override
    public int getKilledPieces(){
        return this.numberOfKilledPieces;
    }
    @Override
    public void checkTurn() {
        if(this.has_played){
            this.has_played=false;
        }else {
            this.has_played = true;
        }
    }

    @Override
    public void setPiecesforplaying() {
        Piece Dragon = new Dragon("Red","dragonR");
        this.piecesforplaying.add(Dragon);
        Piece Mage = new Mage("Red","mageR");
        this.piecesforplaying.add(Mage);
        Piece Flag =new Flag("Red","flagR");
        this.piecesforplaying.add(Flag);
        Piece Slayer =new Slayer("Red","slayerR");
        this.piecesforplaying.add(Slayer);
        Piece Knight1 =new Knight("Red","knightR");
        this.piecesforplaying.add(Knight1);
        Piece Knight2 =new Knight("Red","knightR");
        this.piecesforplaying.add(Knight2);
        Piece BeastRider1 = new BeastRider("Red","beastRiderR");
        this.piecesforplaying.add(BeastRider1);
        Piece BeastRider2 = new BeastRider("Red","beastRiderR");
        this.piecesforplaying.add(BeastRider2);
        Piece BeastRider3 = new BeastRider("Red","beastRiderR");
        this.piecesforplaying.add(BeastRider3);
        Piece Sorceress1 = new Sorceress("Red","sorceressR");
        this.piecesforplaying.add(Sorceress1);
        Piece Sorceress2 = new Sorceress("Red","sorceressR");
        this.piecesforplaying.add(Sorceress2);
        Piece LavaBeast1 = new LavaBeast("lavaBeast");
        this.piecesforplaying.add(LavaBeast1);
        Piece LavaBeast2 = new LavaBeast("lavaBeast");
        this.piecesforplaying.add(LavaBeast2);
        Piece Elf1 = new Elf("Red","elfR");
        this.piecesforplaying.add(Elf1);
        Piece Elf2 = new Elf("Red","elfR");
        this.piecesforplaying.add(Elf2);
        Piece Dwarf1 = new Dwarf("Red","dwarfR");
        this.piecesforplaying.add(Dwarf1);
        Piece Dwarf2 = new Dwarf("Red","dwarfR");
        this.piecesforplaying.add(Dwarf2);
        Piece Dwarf3 = new Dwarf("Red","dwarfR");
        this.piecesforplaying.add(Dwarf3);
        Piece Dwarf4 = new Dwarf("Red","dwarfR");
        this.piecesforplaying.add(Dwarf4);
        Piece Dwarf5 = new Dwarf("Red","dwarfR");
        this.piecesforplaying.add(Dwarf5);
        Piece Scout1 = new Scout("Red","scoutR");
        this.piecesforplaying.add(Scout1);
        Piece Scout2 = new Scout("Red","scoutR");
        this.piecesforplaying.add(Scout2);
        Piece Scout3 = new Scout("Red","scoutR");
        this.piecesforplaying.add(Scout3);
        Piece Scout4 = new Scout("Red","scoutR");
        this.piecesforplaying.add(Scout4);
        Piece Trap1 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap1);
        Piece Trap2 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap2);
        Piece Trap3 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap3);
        Piece Trap4 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap4);
        Piece Trap5 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap5);
        Piece Trap6 = new Trap("Red","trapR");
        this.piecesforplaying.add(Trap6);
    }

    @Override
    public void countAttacks() {
        Attacks++;
    }

    @Override
    public void Played() {
        this.has_played=true;
    }

    @Override
    public double getSuccessfullAttacks() {
        if(Attacks!=0 ) {
            return  Attacks;
        }else{
            return 0;
        }
    }

    @Override
    public Piece returnRandomPiece() {
        tempPieces=piecesforplaying;
        int index = (int)(Math.random() * tempPieces.size());
        Piece piece =tempPieces.get(index);
        tempPieces.remove(index);
        return piece;

    }

    @Override
    public ArrayList<Piece> getTotalKilledPieces() {
        return killedPieces;
    }
    @Override
    public ArrayList<Piece> getPiecesForPlaying() {
        return this.piecesforplaying;
    }
}

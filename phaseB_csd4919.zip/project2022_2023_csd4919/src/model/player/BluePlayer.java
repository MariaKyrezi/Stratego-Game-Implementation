package model.player;

//import model.collection.Collection;
import controller.Controller;
import model.piece.*;
import view.View;

import java.util.ArrayList;
import java.util.Random;
public class BluePlayer implements Player {
    private String name;
    private int TotalSaves=0;
    private boolean has_played;
    public ArrayList<Piece> killedPieces;
    public int numberOfKilledPieces=0,Attacks=0;
    private ArrayList<Piece> piecesForPlaying;

    /**
     * Constructor: Makes a new Blue Player and initializes the player's pieces for playing as well as an Arraylist where in the future will be added  all the killed pieces
     */
    public BluePlayer(){

        setName("Everwinter");
        this.has_played=false;
        this.piecesForPlaying=new ArrayList<Piece>(30);
        setPiecesforplaying();
        killedPieces= new ArrayList<>();

    }

    /**
     * Method that adds the specific piece in the Arraylist of killed Pieces of the player
     * @param piece is the killed piece of the opponent after an attack
     */
    public void addKilledPieceInList(Piece piece){
        this.killedPieces.add(piece);
        numberOfKilledPieces++;
    }

    /**
     * Method that returns the number of pieces saved by the player
     * @return the number of pieces saved
     */
    public int getTotalSaves(){
        return this.TotalSaves;
    }

    /**
     * Method that counts the total saves of the player.
     * The total is being counted by adding the total of saves of each piece the player has in his collection.
     */
    public void countTotalSaves(){
        TotalSaves++;
    }

    /**
     * Method that returns a random piece from the collection of pieces that the player has
     * @return a random piece from the already set pieces for playing
     */
    public Piece returnRandomPiece(){
        ArrayList<Piece> tempPieces = piecesForPlaying;
        int index = (int)(Math.random() * tempPieces.size());
        Piece piece = tempPieces.get(index);
        tempPieces.remove(index);
        return piece;

    }

    /**
     * Method that removes a piece from the list of pieces for playing of the player
     * @param piece is the piece removed from the player's pieces for playing
     */
    public void removePiece(Piece piece){
        this.piecesForPlaying.remove(piece);
    }

    /**
     * Method that returns the pieces for playing of the player
     * @return the pieces for playing of the player
     */
    public ArrayList<Piece> getPiecesForPlaying(){
        return this.piecesForPlaying;
    }

    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void checkTurn() {
        if(this.has_played){
            this.has_played=false;
        }else{
            this.has_played = true;
        }
    }

    /**
     * Method that sets the needed pieces for the player to start playing
     */
    public void setPiecesforplaying() {
        Piece Dragon = new Dragon("Blue","dragonB");
        this.piecesForPlaying.add(Dragon);
        Piece Mage = new Mage("Blue","mageB");
        this.piecesForPlaying.add(Mage);
        Piece Flag =new Flag("Blue","flagB");
        this.piecesForPlaying.add(Flag);
        Piece Slayer =new Slayer("Blue","slayerB");
        this.piecesForPlaying.add(Slayer);
        Piece Knight1 =new Knight("Blue","knightB");
        this.piecesForPlaying.add(Knight1);
        Piece Knight2 =new Knight("Blue","knightB");
        this.piecesForPlaying.add(Knight2);
        Piece BeastRider1 = new BeastRider("Blue","beastRiderB");
        this.piecesForPlaying.add(BeastRider1);
        Piece BeastRider2 = new BeastRider("Blue","beastRiderB");
        this.piecesForPlaying.add(BeastRider2);
        Piece BeastRider3 = new BeastRider("Blue","beastRiderB");
        this.piecesForPlaying.add(BeastRider3);
        Piece Sorceress1 = new Sorceress("Blue","sorceressB");
        this.piecesForPlaying.add(Sorceress1);
        Piece Sorceress2 = new Sorceress("Blue","sorceressB");
        this.piecesForPlaying.add(Sorceress2);
        Piece Yeti1 = new Yeti("yeti");
        this.piecesForPlaying.add(Yeti1);
        Piece Yeti2 = new Yeti("yeti");
        this.piecesForPlaying.add(Yeti2);
        Piece Elf1 = new Elf("Blue","elfB");
        this.piecesForPlaying.add(Elf1);
        Piece Elf2 = new Elf("Blue","elfB");
        this.piecesForPlaying.add(Elf2);
        Piece Dwarf1 = new Dwarf("Blue","dwarfB");
        this.piecesForPlaying.add(Dwarf1);
        Piece Dwarf2 = new Dwarf("Blue","dwarfB");
        this.piecesForPlaying.add(Dwarf2);
        Piece Dwarf3 = new Dwarf("Blue","dwarfB");
        this.piecesForPlaying.add(Dwarf3);
        Piece Dwarf4 = new Dwarf("Blue","dwarfB");
        this.piecesForPlaying.add(Dwarf4);
        Piece Dwarf5 = new Dwarf("Blue","dwarfB");
        this.piecesForPlaying.add(Dwarf5);
        Piece Scout1 = new Scout("Blue","scoutB");
        this.piecesForPlaying.add(Scout1);
        Piece Scout2 = new Scout("Blue","scoutB");
        this.piecesForPlaying.add(Scout2);
        Piece Scout3 = new Scout("Blue","scoutB");
        this.piecesForPlaying.add(Scout3);
        Piece Scout4 = new Scout("Blue","scoutB");
        this.piecesForPlaying.add(Scout4);
        Piece Trap1 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap1);
        Piece Trap2 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap2);
        Piece Trap3 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap3);
        Piece Trap4 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap4);
        Piece Trap5 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap5);
        Piece Trap6 = new Trap("Blue","trapB");
        this.piecesForPlaying.add(Trap6);
    }

    /**
     * Method that sets the variable has played as true
     */
    @Override
    public void Played() {
        this.has_played=true;
    }
    @Override
    public ArrayList<Piece> getTotalKilledPieces() {
        return killedPieces;
    }

    /**
     * Method that returns the number of pieces that the player has killed
     * @return the number of opponent's killed pieces
     */
    public int getKilledPieces(){
        return this.numberOfKilledPieces;
    }

    /**
     * Method that counts the attacks the player has made
     */
    public void countAttacks(){
        Attacks++;
    }
    @Override
    public double getSuccessfullAttacks() {
        if(Attacks!=0) {
            return Attacks;
        }else{
            return 0;
        }
    }
}

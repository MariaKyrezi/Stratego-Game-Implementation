package model.piece;

import controller.Controller;
import model.board.Board;
import model.player.BluePlayer;
import model.player.Player;

import static java.lang.System.exit;

public class MovablePiece implements Piece{
    private String name,colour;
    private int rank,x_coordinate,y_coordinate,count_saves;
    Board b = new Board();

    /**
     * Constructor: Makes a new movable piece for the game with the given name and x, y coordinates
     * @param colour is the colour we want to set the piece with
     * @param name is the name of the piece
     */
    public MovablePiece(String colour,String name){
        setName(name);
        setColour(colour);
    }

    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setRank(int rank) {
        this.rank=rank;
    }

    @Override
    public int getRank() {
        return this.rank;
    }

    @Override
    public void setX(int x) {
        this.x_coordinate=x;
    }

    @Override
    public int getX() {
        return this.x_coordinate;
    }

    @Override
    public void setY(int y) {
        this.y_coordinate=y;
    }

    @Override
    public int getY() {
        return this.y_coordinate;
    }

    @Override
    public void setColour(String colour) {
        this.colour=colour;
    }

    @Override
    public String getColour() {
        return this.colour;
    }


    // piece1 attacks... piece2 defends
    //have to see if blue or red attacks

    /**
     * Transformer:
     * Method that makes a movable piece1 attack another piece2
     * and makes all the needed changes on the board and on the lists of the players.
     * pre-condition: piece2 can be any type of piece, movable or immovable
     * @param player1 is the RedPlayer
     * @param player2 is the BluePlayer
     * @param piece1 is the piece that attacks
     * @param piece2 is the piece that defends
     * @param x is the x coordinate of the defending piece
     * @param y is the y coordinate of the defending piece
     * @param prevx is the x coordinate of the attacking piece
     * @param prevy is the y coordinate of the attacking piece
     */
    public void attack(Player player1,Player player2,Piece piece1,Piece piece2, int x, int y, int prevx, int prevy){
        if(piece1.getRank()>piece2.getRank() && piece1.getRank()!=3 && piece1.getRank()!=1 ) {
            b.setMovedPiece(x, y, prevx, prevy, piece1); // moves the piece on the board
            removeKilledPieceFromBoard(player1,player2,piece2); // removes the piece that lost in the attack from the board
        }else if(piece1.getRank()<piece2.getRank() && piece1.getRank()!=3 && piece1.getRank()!=1){
            b.setMovedPiece(x,y,prevx, prevy,null);
            removeKilledPieceFromBoard(player1,player2,piece1);
        } else if (piece1.getRank()==piece2.getRank()) {
            b.setMovedPiece(x, y, prevx, prevy, piece1);
            b.setMovedPiece(x,y,x,y,piece2); // it doesn't matter what piece i put there
            removeKilledPieceFromBoard(player1,player2,piece1);
            removeKilledPieceFromBoard(player1,player2,piece2);
        } else if (piece1.getRank()==3  ) {
            if(piece2.getRank()==11) {
                b.setMovedPiece(x, y, prevx, prevy, piece1);
                removeKilledPieceFromBoard(player1,player2,piece2);
            }else{
                if(piece1.getRank()>piece2.getRank()){
                    b.setMovedPiece(x, y, prevx, prevy, piece1);
                    removeKilledPieceFromBoard(player1,player2,piece2);
                }else if(piece1.getRank()==piece2.getRank()){
                    b.setMovedPiece(x, y, prevx, prevy, null);
                    removeKilledPieceFromBoard(player1,player2,piece2);
                    removeKilledPieceFromBoard(player1,player2,piece1);
                }else{
                    b.setMovedPiece(x, y, prevx, prevy, piece2);
                    removeKilledPieceFromBoard(player1,player2,piece1);
                }
            }
        } else if (piece1.getRank()==1) {
            if(piece2.getRank()==10) {
                b.setMovedPiece(x, y, prevx, prevy, piece1);
                removeKilledPieceFromBoard(player1,player2,piece2);
            }else{
                if(piece1.getRank()>piece2.getRank()){
                    b.setMovedPiece(x, y, prevx, prevy, piece1);
                    removeKilledPieceFromBoard(player1,player2,piece2);
                }else if(piece1.getRank()==piece2.getRank()){
                    b.setMovedPiece(x, y, prevx, prevy, null);
                    removeKilledPieceFromBoard(player1,player2,piece2);
                    removeKilledPieceFromBoard(player1,player2,piece1);
                }else{
                    b.setMovedPiece(x, y, prevx, prevy, piece2);
                    removeKilledPieceFromBoard(player1,player2,piece1);
                }
            }
        }
    }

    /**
     * Method that removes the piece that lost in the attack from the list of pieces of the player with the same colour
     * and adds it in the opponent's list of killed pieces
     * @param playerRed is the player with colour red
     * @param BluePlayer is the player with blue colour
     * @param piece is the piece that lost in the attack
     */
    public void removeKilledPieceFromBoard(Player playerRed,Player BluePlayer, Piece piece){

        if(piece.getColour()=="Red"){
            if(piece instanceof Flag){
                Controller controller=new Controller();
                controller.winner("blue");
                exit(0);
            }
            BluePlayer.addKilledPieceInList(piece); // adds opponent's piece in the list of dead pieces of bluePlayer
            playerRed.removePiece(piece); // removes piece from player's list of pieces
        }else{
            if(piece instanceof Flag){
                Controller controller=new Controller();
                controller.winner("red");
                exit(0);
            }
            playerRed.addKilledPieceInList(piece); // adds opponent's piece in the list of dead pieces of RedPlayer
            BluePlayer.removePiece(piece); // removes piece from player's list of pieces
        }
    }

    /**
     * Transformer:
     * Method that moves the piece in the correct place on the board
     * @param x is the x coordinate the piece wants to move onto
     * @param y is the y coordinate the piece wants to move onto
     * @param piece is the piece we want to move
     * @param prevX is the starting x coordinate
     * @param prevY is the starting y coordinate
     */
    public void move(int x, int y,int prevX, int prevY, Piece piece){
        b.setMovedPiece(x,y,prevX,prevY,piece);
    }

    /**
     * Accessor:
     * Method that checks if the piece can move in correct places
     * @param pieces is the board where all the pieces have been set with x,y coordinates
     * @param piece is the piece we want to move
     * @return true or false if the piece can move in the wanted place or not based on the rules of the game
     */
    public boolean canMove(Piece[][] pieces,Piece piece){
        int i=piece.getX();
        int j= piece.getY();

        if (i == 0 && j == 0) {
            if (pieces[i + 1][j] == null || pieces[i][j + 1] == null) {
                return true;
            }else{
                return false;
            }
        } else if (i==7 && j==9){
            if(pieces[i-1][j]==null || pieces[i][j-1]==null ){
                return true;
            }else {
                return false;
            }
        } else if (i==0 && j==9) {
            if (pieces[i + 1][j] == null || pieces[i][j -1] == null) {
                return true;
            }else{
                return false;
            }
        } else if (i==7 && j==0) {
            if(pieces[i][j+1]==null || pieces[i-1][j]==null){
                return true;
            }else {
                return false;
            }
        } else if(i==0){

            if(pieces[i][j-1]==null || pieces[i][j+1]==null || pieces[i+1][j]==null){
                return true;
            }else{
                return false;
            }

        }else if(j==0){

            if(pieces[i+1][j]==null || pieces[i][j+1]==null || pieces[i-1][j]==null){
                return true;
            }else {
                return false;
            }

        } else if (j==9) {

            if(pieces[i+1][j]==null || pieces[i-1][j]==null || pieces[i][j-1]==null ){
                return true;
            }else {
                return false;
            }
        } else if (i==7) {
            if(pieces[i][j+1]==null || pieces[i-1][j]==null || pieces[i][j-1]==null ){
                return true;
            }else {
                return false;
            }
        } else{
            if(pieces[i+1][j]==null || pieces[i][j+1]==null || pieces[i-1][j]==null || pieces[i][j-1]==null ){
                return true;
            }else {
                return false;
            }
        }
    }
    /**
     * Accessor:
     * Method that checks if the piece can attack from his current position
     * @param pieces is the board where all the pieces have been set with x,y coordinates
     * @param piece is the piece we want to move
     * @return true or false if the piece can move in the wanted place or not based on the rules of the game
     */
    public boolean canAttack(Piece[][] pieces,Piece piece){
        int i=piece.getX();
        int j= piece.getY();

        if (i == 0 && j == 0) {
            if ((pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour() &&pieces[i+1][j].getName()!="Restricted") || (pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted")) {
                return true;
            }else{
                return false;
            }
        } else if (i==7 && j==9){
            if((pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour()&& pieces[i-1][j].getName()!="Restricted") || (pieces[i][j-1]!=null && pieces[i][j-1].getColour()!=piece.getColour() && pieces[i][j-1].getName()!="Restricted") ){
                return true;
            }else {
                return false;
            }
        } else if (i==0 && j==9) {
            if ((pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour()&&pieces[i+1][j].getName()!="Restricted") || (pieces[i][j-1]!=null && pieces[i][j -1].getColour()!=piece.getColour())&&pieces[i][j-1].getName()!="Restricted") {
                return true;
            }else{
                return false;
            }
        } else if (i==7 && j==0) {
            if((pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted") || (pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour())&&pieces[i-1][j].getName()!="Restricted"){
                return true;
            }else {
                return false;
            }
        } else if(i==0){

            if((pieces[i][j-1]!=null && pieces[i][j-1].getColour()!=piece.getColour()&&pieces[i][j-1].getName()!="Restricted")|| (pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted") || (pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour())&&pieces[i+1][j].getName()!="Restricted"){
                return true;
            }else{
                return false;
            }

        }else if(j==0){

            if((pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted") || (pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour()&&pieces[i+1][j].getName()!="Restricted")|| (pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour())&&pieces[i-1][j].getName()!="Restricted"){
                return true;
            }else {
                return false;
            }

        } else if (j==9) {

            if((pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour()&&pieces[i+1][j].getName()!="Restricted") || (pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour()&&pieces[i-1][j].getName()!="Restricted") || (pieces[i][j-1]!=null && pieces[i][j-1].getColour()!=piece.getColour()&&pieces[i][j-1].getName()!="Restricted") ){
                return true;
            }else {
                return false;
            }
        } else if (i==7) {
            if((pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted") || (pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour()&&pieces[i-1][j].getName()!="Restricted") || (pieces[i][j-1]!=null && pieces[i][j-1].getColour()!=piece.getColour()&&pieces[i][j-1].getName()!="Restricted") ){
                return true;
            }else {
                return false;
            }
        } else{
            if((pieces[i][j+1]!=null && pieces[i][j + 1].getColour()!=piece.getColour()&&pieces[i][j+1].getName()!="Restricted") || (pieces[i+1][j]!=null && pieces[i + 1][j].getColour()!=piece.getColour()&&pieces[i+1][j].getName()!="Restricted") || (pieces[i-1][j]!=null && pieces[i-1][j].getColour()!=piece.getColour()&&pieces[i-1][j].getName()!="Restricted") || (pieces[i][j-1]!=null && pieces[i][j-1].getColour()!=piece.getColour()&&pieces[i][j-1].getName()!="Restricted") ){
                return true;
            }else {
                return false;
            }
        }
    }

    /**
     * Transformer:
     * Method that returns a piece to the game that has been previously removed
     * @param piece1 the piece that is returned to the game
     * @return the piece that is returned to the game
     */
    public Piece save(Piece piece1){
        return null;
    }

    /**
     * Method that checks if the wanted piece can be saved and returned to the game
     * @param piece is the piece that the player wants to rescue
     * @return true or false if it's possible to rescue this piece
     */
    public boolean CanBeSaved(Piece piece){ return false;}

    /**
     * Method that sets the number of saves the piece has made
     * pre-condition: the number has to be less than two
     * @param count_saves is the number of pieces the particular piece has saved
     */
    public void setCount_saves(int count_saves){
        this.count_saves=count_saves;
    }

    /**
     * Method that returns the number of saves the particular piece has made
     * post-condition: returns a number from 0 to 2
     * @return the number of saves the piece has made
     */
    public int getCount_saves(){
        return this.count_saves;
    }


}

package model.piece;

public class RestrictedArea implements Piece{
    String name;
    int x,y,rank;

    public RestrictedArea(){
        setName("Restricted");
    }
    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setRank(int rank) {
        this.rank=rank;
    }

    @Override
    public int getRank() {
        return 0;
    }

    @Override
    public void setX(int x) {
        this.x=x;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public void setY(int y) {
        this.y=y;
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public void setColour(String colour) {

    }

    @Override
    public String getColour() {
        return null;
    }
}

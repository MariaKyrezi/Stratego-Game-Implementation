package model.piece;

public class Dragon extends MovablePiece{

    public Dragon(String colour,String name) {
        super(colour,name);
        setRank(10);
    }
}

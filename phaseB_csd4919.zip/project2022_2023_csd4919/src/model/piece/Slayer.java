package model.piece;

public class Slayer extends SpecialMovablePiece{
    public Slayer( String colour,String name) {
        super(colour,name);
        setRank(1);
    }
}

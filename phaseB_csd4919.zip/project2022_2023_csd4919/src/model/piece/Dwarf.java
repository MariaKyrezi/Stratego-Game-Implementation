package model.piece;

import model.player.Player;

public class Dwarf extends SpecialMovablePiece{
    public Dwarf(String colour,String name) {
        super(colour,name);
        setRank(3);
    }


}

package model.piece;

public class Trap extends ImmovablePiece{

    public Trap(String colour,String name) {
        super(colour,name);
        setRank(11);
    }
}

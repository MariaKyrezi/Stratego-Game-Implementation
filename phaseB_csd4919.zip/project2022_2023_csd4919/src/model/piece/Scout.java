package model.piece;

public class Scout extends SpecialMovablePiece {

    public Scout(String colour,String name) {
        super(colour,name);
        setRank(2);
    }
}

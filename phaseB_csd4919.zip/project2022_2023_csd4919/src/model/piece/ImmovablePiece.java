package model.piece;

public class ImmovablePiece implements Piece{

    private String name,colour;
    private int rank,x,y;

    ImmovablePiece(String colour1,String name){
        setColour(colour1);
        setName(name);
    }

    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
       return this.name;
    }

    @Override
    public void setRank(int rank) {
        this.rank=rank;
    }

    @Override
    public int getRank() {
        return this.rank;
    }

    @Override
    public void setX(int x) {
        this.x=x;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public void setY(int y) {
        this.y=y;
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public void setColour(String colour) {
        this.colour=colour;
    }

    @Override
    public String getColour() {
        return this.colour;
    }
}

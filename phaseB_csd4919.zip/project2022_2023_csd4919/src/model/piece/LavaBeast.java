package model.piece;

public class LavaBeast extends MovablePiece{
    public LavaBeast(String name) {
        super("Red",name);
        setRank(5);
    }
}

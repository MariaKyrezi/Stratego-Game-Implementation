package model.piece;

public class Knight extends MovablePiece{
    public Knight(String colour,String name) {
        super(colour,name);
        setRank(8);
    }
}

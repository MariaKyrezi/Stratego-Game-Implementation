package model.piece;

public class SpecialMovablePiece extends MovablePiece{
    public SpecialMovablePiece(String colour,String name) {
        super(colour,name);
    }


}

package model.piece;

public class Yeti extends MovablePiece{

    public Yeti(String name) {
        super("Blue",name);
        setRank(5);
    }
}

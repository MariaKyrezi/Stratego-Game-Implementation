package model.piece;

public class Mage extends MovablePiece{
    public Mage(String colour,String name) {
        super(colour,name);
        setRank(9);
    }
}

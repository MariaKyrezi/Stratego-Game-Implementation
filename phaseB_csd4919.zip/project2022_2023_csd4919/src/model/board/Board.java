package model.board;

import model.piece.Piece;
import model.player.Player;

import java.util.ArrayList;

public class Board {


    /**
     * Make's a board following stratego's instructions that has 8 raws and 10 columns
     */
    Piece[][] board;

    public Board(){
        board= new Piece[8][10];
    }

    /**
     * Method that copies an already initialised board with the appropriate pieces of each player to the board of the game
     * @param board is the board of the game where all the pieces exist
     */
    public void putPiecesOnBoard(Piece[][] board){
        this.board=board;

    }

    /**
     * Method that "moves" a piece on the board. This movement can be a result of attack or movement of the piece.
     * @param x is the new x coordinate of the piece
     * @param y is the new y coordinate of the piece
     * @param prevX is the previous x coordinate that the moved piece was or the piece that lost in the attack was
     * @param prevY is the previous y coordinate that the moved piece was or the piece that lost in the attack was
     * @param piece is the piece that we want to have the new x,y coordinates because it moved in an empty spot or because it won in an attack
     */
    public void setMovedPiece(int x, int y, int prevX,int prevY,Piece piece){
        if(piece!=null) {
            this.board[x][y] = piece;
            this.board[x][y].setX(x);
            this.board[x][y].setY(y);
            this.board[x][y].setRank(piece.getRank());
            this.board[prevX][prevY] = null;
        }else if(x==prevX && y==prevY) {
            this.board[x][y] = null;
        }else{
            this.board[x][y] = piece;
            this.board[prevX][prevY] = null;
        }
    }

    /**
     * Method that returns a piece with specific (x,y) coordinates from the board
     * @param x is the x coordinate
     * @param y is the y coordinate
     * @return the piece in the given position on the board
     */
    public Piece returnPiece(int x, int y){
        return this.board[x][y];
    }

    /**
     * Method that returns the board of the game in the exact moment
     * @return the board of the game with the pieces in the positions of exactly that time
     */
    public Piece[][] getBoard(){
        return this.board;
    }
    /**
     * Method that adds the piece in a specific place on the board because another piece saved it
     * @param piece is the piece that has previously lost in an attack, and we want to revive
     * @param x_coordinate is the x coordinate in which the piece will be put on the board
     * @param y_coordinate is the x coordinate in which the piece will be put on the board
     * @return the piece that has been added on the board in the specific place
     */
    public Piece addNewPieceOnBoard(Piece piece, int x_coordinate, int y_coordinate){
        return null;
    }

}

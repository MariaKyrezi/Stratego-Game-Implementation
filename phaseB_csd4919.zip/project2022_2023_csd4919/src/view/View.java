package view;

import controller.Controller;
import model.board.Board;
import model.piece.MovablePiece;
import model.piece.Piece;
import model.player.Player;
import model.player.RedPlayer;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import java.lang.Math;

public class View extends JFrame {

    JFrame frame;// the frame of the game
    JPanel panel; // the panel where the board will be added
    JPanel menuPanel = new JPanel(); // the panel where the menu will be added
    JPanel icons =new JPanel(); // the panel where the icons of the killed pieces will be added... i hanen't done that because sth didn't work
    //JPanel menuPanel;
    int rank,prevx, prevy;

    static JButton[][] tempo=new JButton[8][10]; // a temporary board identical to the board of buttons but used to change the visibility
    String col,card; // variables needed for method getImage()
    public ArrayList<Player> players; // the players of the game
    MovablePiece tempPiece; // will be used as the piece that wants to move or attack
    private boolean iconSelected; // checks if a button is selected to move
    private JButton selectedButton, seltempo; //the button selected to move or attack
    public String cardname="1",colourCard="2",colour;
    Board board = new Board(); // constructs a model board
    Piece[][] pieces; // the board of pieces (a copy of the board of the game)
    JButton[][] b=new JButton[8][10]; // the board of buttons

    Controller controller=new Controller();

    /**
     * Constructor that makes a new window and puts the board of the game and the menu with all needed information
     */
    public View(){

        frame = new JFrame("Game");
        frame.setLayout(new BorderLayout());
        players=controller.getPlayers();
        pieces=controller.getBoardController();

        this.setTitle("STRATEGO");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        CardListener cl = new CardListener();

        panel = new JPanel();
        panel.setLayout(new GridLayout(8, 10));
        Board board =new Board();
        menuPanel.setLayout(new GridLayout(11,1));
        icons.setLayout(new GridLayout(1,15));

        for (int i = 0; i < 8; i++) {
            for(int j = 0; j < 10 ; j++) {
                b[i][j] = new JButton();
                tempo[i][j]=new JButton();
                Piece t=controller.returnBoardPiece(i,j);

                if (i <=2) {
                    cardname=t.getName();
                    colourCard="Red";

                    b[i][j].setIcon(getImageCard());
                    b[i][j].setName(cardname);

                    tempo[i][j].setIcon(getImageCard());
                    tempo[i][j].setName(cardname);
                } else if ((i == 3 && j==2)||(i == 3 && j==3)||(i == 3 && j==6)||(i == 3 && j==7)||(i == 4 && j==2)||(i == 4 && j==3)||(i == 4 && j==6)||(i == 4 && j==7)) {

                    b[i][j].setName("restricted");
                    b[i][j].setIcon(getImageRestricted());

                    tempo[i][j].setName("restricted");
                    tempo[i][j].setIcon(getImageRestricted());
                } else if(i>=5) {
                    colourCard="blue";
                    cardname=t.getName();
                    b[i][j].setIcon(getImageCard());
                    b[i][j].setName(cardname);

                    tempo[i][j].setIcon(getImageCard());
                    tempo[i][j].setName(cardname);
                }else{
                    rank=0;
                    cardname="green";
                    b[i][j].setIcon(getImageBack());
                    tempo[i][j].setIcon(getImageBack());
                }
                b[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                b[i][j].addMouseListener(cl);
                panel.add(b[i][j]);
            }
        }
        add(panel,BorderLayout.CENTER);
        changeMenu(players.get(0));
        add(menuPanel,BorderLayout.EAST);
        add(icons,BorderLayout.SOUTH);

        iconSelected = false;
    }

    /**
     * Method that returns the image of green area
     * @return an imagicon with the image of the green area
     */
    private ImageIcon getImageBack() { // image for background
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/green.jpg")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method that returns the image of the Restricted Area
     * @return the ImageIcon with the image of the Restricted Areas
     */
    private ImageIcon getImageRestricted() { // image for background
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/RestrictedArea.jpg")).getScaledInstance(90,80,Image.SCALE_SMOOTH));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Method that returns the image of a specific piece from the file
     * @return the image of the piece
     */
    private ImageIcon getImageCard() { // image for card
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/"+colourCard+"Pieces/"+cardname+".png"))
                    .getScaledInstance(90, 80, Image.SCALE_SMOOTH)); // image
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    /**
     *  Method that returns the image of the hidden pieces
     * @return returns ImageIcon of the hidden pieces
     */
    private ImageIcon getImage() { // image for cardhidden
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/"+col+"Pieces/"+card+".png"))
                    .getScaledInstance(90, 80, Image.SCALE_SMOOTH)); // image
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    /**
     * Illustrates all the movements - attacks and the changing of the visual of the frame
     */
    private class CardListener implements MouseListener {
        @Override
        public void mouseClicked(MouseEvent e) {
            for(int i=0;i<8;i++){
                for(int j=0;j<10;j++){
                    if(b[i][j]==((JButton) e.getSource())){
                        JButton but = ((JButton) e.getSource());
                        if (iconSelected && !but.equals(selectedButton) && but.getName()!="restricted" ) { // move(swap) buttons && tempPiece.getRank()!=3 && tempPiece.getRank()!=1
                            if(pieces[i][j]==null){
                                colour="green";
                                System.out.println("green");
                            } else if (pieces[i][j].getColour()=="Red") {
                                colour="Red";
                                System.out.println("red");
                            }else if(pieces[i][j].getColour()=="blue"){
                                colour="blue";
                                System.out.println("blue");
                            }else{
                                colour="black";
                            }
                            if(colourCard!=colour) {
                                if ((Math.abs(tempPiece.getX() - i) <= 1 && Math.abs(tempPiece.getY() - j) < 1) || (Math.abs(tempPiece.getX() - i) < 1 && Math.abs(tempPiece.getY() - j) <= 1)) {
                                    if(pieces[i][j] == null || (tempPiece.getRank()==3 && pieces[i][j].getRank()==11)|| (tempPiece.getRank()==1 && pieces[i][j].getRank()==10)){
                                        moveButton(selectedButton,but);
                                        moveButton(seltempo,tempo[i][j]);

                                        if (pieces[i][j] != null) {
                                            tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                        } else {
                                            tempPiece.move(i, j, prevx, prevy, tempPiece);
                                        }
                                        pieces[i][j] = tempPiece;
                                        pieces[i][j].setX(i);
                                        pieces[i][j].setY(j);
                                        pieces[i][j].setRank(tempPiece.getRank());
                                        pieces[prevx][prevy] = null;
                                        tempPiece = null;
                                        rank = 0;
                                        board.putPiecesOnBoard(pieces);

                                        if(colourCard=="Red"){
                                            changeMenu(players.get(1));
                                        }else{
                                            changeMenu(players.get(0));
                                        }

                                    } else if ( pieces[i][j].getRank() < rank) {
                                        moveButton(selectedButton,but);
                                        moveButton(seltempo,tempo[i][j]);
                                        if (pieces[i][j] != null) {
                                            tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                        } else {
                                            tempPiece.move(i, j, prevx, prevy, tempPiece);
                                        }
                                        pieces[i][j] = tempPiece;
                                        pieces[i][j].setX(i);
                                        pieces[i][j].setY(j);
                                        pieces[i][j].setRank(tempPiece.getRank());
                                        pieces[prevx][prevy] = null;
                                        tempPiece = null;

                                        rank = 0;
                                        board.putPiecesOnBoard(pieces);

                                        if(colourCard=="Red"){
                                            changeMenu(players.get(1));
                                            players.get(0).countAttacks();
                                        }else{
                                            changeMenu(players.get(0));
                                            players.get(1).countAttacks();
                                        }
                                    } else if (pieces[i][j].getRank() == rank) {

                                        selectedButton.setIcon(getImageBack());
                                        selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                        selectedButton.setName("green");

                                        but.setIcon(getImageBack());
                                        but.setBorder(BorderFactory.createLineBorder(Color.black));
                                        but.setName("green");
                                        seltempo.setIcon(getImageBack());
                                        seltempo.setBorder(BorderFactory.createLineBorder(Color.black));
                                        seltempo.setName("green");

                                        tempo[i][j].setIcon(getImageBack());
                                        tempo[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                                        tempo[i][j].setName("green");

                                        iconSelected = false;
                                        tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                        pieces[i][j] = null;
                                        pieces[prevx][prevy] = null;
                                        tempPiece = null;
                                        rank = 0;
                                        if(colourCard=="Red"){
                                            changeMenu(players.get(1));
                                            players.get(0).countAttacks();
                                        }else{
                                            changeMenu(players.get(0));
                                            players.get(1).countAttacks();
                                        }
                                    }else {
                                        selectedButton.setIcon(getImageBack());
                                        selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                        selectedButton.setName("green");
                                        seltempo.setIcon(getImageBack());
                                        seltempo.setBorder(BorderFactory.createLineBorder(Color.black));
                                        seltempo.setName("green");
                                        iconSelected = false;
                                        tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                        pieces[prevx][prevy] = null;
                                        rank = 0;
                                        tempPiece = null;

                                        if(colourCard=="Red"){
                                            changeMenu(players.get(1));
                                            players.get(0).countAttacks();
                                        }else{
                                            changeMenu(players.get(0));
                                            players.get(1).countAttacks();
                                        }
                                    }
                                }else{
                                    if(tempPiece.getRank()==2){
                                        if(isValidMove(tempPiece,i,j,pieces)){
                                            if(pieces[i][j]==null) {
                                                moveButton(selectedButton,but);
                                                moveButton(seltempo,tempo[i][j]);
                                                if (pieces[i][j] != null) {
                                                    tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                                } else {
                                                    tempPiece.move(i, j, prevx, prevy, tempPiece);
                                                }
                                                pieces[i][j] = tempPiece;
                                                pieces[i][j].setX(i);
                                                pieces[i][j].setY(j);
                                                pieces[i][j].setRank(tempPiece.getRank());
                                                pieces[prevx][prevy] = null;
                                                tempPiece = null;
                                                //ayta paramenoyn
                                                rank = 0;
                                                board.putPiecesOnBoard(pieces);
                                                if(colourCard=="Red"){
                                                    changeMenu(players.get(1));
                                                }else{
                                                    changeMenu(players.get(0));
                                                }
                                            }else if(tempPiece.getRank()==pieces[i][j].getRank()){
                                                selectedButton.setIcon(getImageBack());
                                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                                selectedButton.setName("green");
                                                seltempo.setIcon(getImageBack());
                                                seltempo.setBorder(BorderFactory.createLineBorder(Color.black));
                                                seltempo.setName("green");
                                                but.setIcon(getImageBack());
                                                but.setBorder(BorderFactory.createLineBorder(Color.black));
                                                but.setName("green");
                                                tempo[i][j].setIcon(getImageBack());
                                                tempo[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                                                tempo[i][j].setName("green");

                                                iconSelected = false;
                                                tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                                pieces[i][j] = null;
                                                pieces[prevx][prevy] = null;
                                                tempPiece = null;
                                                rank = 0;
                                                if(colourCard=="Red"){
                                                    changeMenu(players.get(1));
                                                    players.get(0).countAttacks();
                                                }else{
                                                    changeMenu(players.get(0));
                                                    players.get(1).countAttacks();
                                                }
                                            }else if(tempPiece.getRank()>pieces[i][j].getRank()){
                                                moveButton(selectedButton,but);
                                                moveButton(seltempo,tempo[i][j]);
                                                //kalv th move toy pieces[i][j] kai kanei ola ta apo katw monh thw
                                                //oti exv kanei sthn move to antigrafw sthn attack kai sth move den xreiazomai prevx, prevy
                                                if (pieces[i][j] != null) {
                                                    tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                                } else {
                                                    tempPiece.move(i, j, prevx, prevy, tempPiece);
                                                }
                                                pieces[i][j] = tempPiece;
                                                pieces[i][j].setX(i);
                                                pieces[i][j].setY(j);
                                                pieces[i][j].setRank(tempPiece.getRank());
                                                pieces[prevx][prevy] = null;
                                                tempPiece = null;
                                                //ayta paramenoyn
                                                rank = 0;
                                                board.putPiecesOnBoard(pieces);
                                                if(colourCard=="Red"){
                                                    changeMenu(players.get(1));
                                                    players.get(0).countAttacks();
                                                }else{
                                                    changeMenu(players.get(0));
                                                    players.get(1).countAttacks();
                                                }
                                            }else{
                                                selectedButton.setIcon(getImageBack());
                                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                                selectedButton.setName("green");
                                                seltempo.setIcon(getImageBack());
                                                seltempo.setBorder(BorderFactory.createLineBorder(Color.black));
                                                seltempo.setName("green");
                                                iconSelected = false;
                                                tempPiece.attack(players.get(0), players.get(1), tempPiece, pieces[i][j], i, j, prevx, prevy);
                                                pieces[prevx][prevy] = null;
                                                rank = 0;
                                                tempPiece = null;
                                                if(colourCard=="Red"){
                                                    changeMenu(players.get(1));
                                                    players.get(0).countAttacks();
                                                }else{
                                                    changeMenu(players.get(0));
                                                    players.get(1).countAttacks();
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        } else if (!iconSelected && but.getName() != null && !but.getName().equals("restricted") && but.getName()!="green" && pieces[i][j].getRank()!=11 && pieces[i][j].getRank()!=0) { // if not selected icon is joker then select
                            tempPiece=(MovablePiece) pieces[i][j];
                            if(tempPiece.canMove(pieces,pieces[i][j]) || tempPiece.canAttack(pieces,pieces[i][j])) {
                                tempPiece.setColour(pieces[i][j].getColour());
                                colourCard = pieces[i][j].getColour();
                                if(colourCard=="Red"){
                                    changeMenu(players.get(0));
                                    controller.increaseRound();
                                    controller.switchTurn("Red");
                                }else{
                                    changeMenu(players.get(1));
                                    controller.switchTurn("blue");

                                }
                                tempPiece.setX(i);
                                tempPiece.setY(j);
                                prevx = i;
                                prevy = j;
                                rank = tempPiece.getRank();
                                iconSelected = true;
                                selectedButton = but;
                                selectedButton.setIcon(but.getIcon());

                                seltempo = tempo[i][j];
                                seltempo.setIcon(but.getIcon());

                                but.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
                            }
                        } else { // if already selected or not selected at all
                            if (iconSelected) {
                                System.out.println("Already Selected");
                            } else {
                                System.out.println("Not selected");
                            }
                        }
                    }
                }
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    }

    /**
     * Method that checks if the scout can move from current position to position with coordinates (curX, curY)
     * @param prev is the piece (scout) we want to move
     * @param curX is the next x coordinate
     * @param curY is the next y coordinate
     * @param pieces is the board of the game
     * @return true or false depending on the correctness of the move
     */
    private boolean isValidMove(Piece prev, int curX, int curY, Piece[][] pieces) {
        // Get the x and y coordinates of the previous and new locations
        int prevX = prev.getX();
        int prevY = prev.getY();

        if (prevX == curX || prevY == curY) {
            // Check if there are no pieces blocking the path (horizontal or vertical)
            if (prevX == curX) {
                for (int i = Math.min(prevY, curY) + 1; i < Math.max(prevY, curY); i++) {
                    if (pieces[prevX][i] != null) {
                        return false;
                    }
                }
            } else {
                for (int i = Math.min(prevX, curX) + 1; i < Math.max(prevX, curX); i++) {
                    if (pieces[i][prevY] != null) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        return true;
    }

    /**
     * Method that moves the buttons in the graphic board
     * @param selected is the button selected to move
     * @param current is the button in the position it wants to move into
     */
    public void moveButton(JButton selected, JButton current){
        current.setIcon(selected.getIcon());
        current.setName(selected.getName());
        current.setBorder(BorderFactory.createLineBorder(new Color(0, 115, 125), 5));
        selected.setIcon(getImageBack());//here i have to fix what color it will return
        selected.setBorder(BorderFactory.createLineBorder(Color.black));
        selected.setName("green");
        iconSelected = false;
    }

    /**
     * Method that makes the menu and changes it everytime one player has played to the other
     * @param player is the player for who we want to show the information
     */
    public void changeMenu(Player player) {
        menuPanel.removeAll();
        //icons.removeAll();
        if(player instanceof RedPlayer){
            JLabel Rules = new JLabel("Existing Rules: ");
            Rules.setOpaque(true);
            Rules.setBackground(Color.LIGHT_GRAY);
            Rules.setFont(new Font("Arial",Font.ITALIC,25));

            JLabel mode = new JLabel("---->  Haven't chosen a specific mode for the game...");
            mode.setOpaque(true);
            mode.setBackground(new Color(239, 162, 162));

            JLabel statistics = new JLabel("Statistics: ");
            statistics.setOpaque(true);
            statistics.setBackground(Color.LIGHT_GRAY);
            statistics.setFont(new Font("Arial",Font.ITALIC,25));

            JLabel playerLabel = new JLabel("---->  RedPlayer's turn");
            playerLabel.setOpaque(true);
            playerLabel.setBackground(new Color(239, 162, 162));

            double percentage;
            if(player.getSuccessfullAttacks()!=0 && players.get(1).getKilledPieces()!=0) {
                percentage = (double) players.get(1).getKilledPieces() / player.getSuccessfullAttacks();
            }else{
                percentage=0;
            }
            JLabel scoreLabel = new JLabel("---->  Percentage of successful attacks of player: "+ percentage);
            scoreLabel.setOpaque(true);
            scoreLabel.setBackground(Color.LIGHT_GRAY);

            JLabel round = new JLabel("---->  Round Number: "+controller.GetRound()); //+ controller get round
            round.setOpaque(true);
            round.setBackground(new Color(239, 162, 162));

            JLabel killedpieces = new JLabel("Total Killed Pieces : "+ player.getTotalKilledPieces().size());
            killedpieces.setOpaque(true);
            killedpieces.setBackground(Color.LIGHT_GRAY);

            /*for(int i=0;i<player.getTotalKilledPieces().size();i++){
                col="Red";
                card=player.getTotalKilledPieces().get(i).getName();
                JLabel icon = new JLabel(getImage());
                icons.add(icon);
            }*/

            menuPanel.add(Rules);
            menuPanel.add(mode);
            menuPanel.add(statistics);
            menuPanel.add(playerLabel);
            menuPanel.add(scoreLabel);
            menuPanel.add(round);
            menuPanel.add(killedpieces);

            changeVisibilityOfCards("blue");

        }else{
            JLabel Rules = new JLabel("Existing Rules: ");
            Rules.setOpaque(true);
            Rules.setBackground(Color.LIGHT_GRAY);
            Rules.setFont(new Font("Arial",Font.ITALIC,25));

            JLabel mode = new JLabel("---->  Haven't chosen a specific mode for the game...");
            mode.setOpaque(true);
            mode.setBackground(new Color(124, 149, 222));

            JLabel statistics = new JLabel("Statistics: ");
            statistics.setOpaque(true);
            statistics.setBackground(Color.LIGHT_GRAY);
            statistics.setFont(new Font("Arial",Font.ITALIC,25));

            JLabel playerLabel = new JLabel("---->  BluePlayer's turn");
            playerLabel.setOpaque(true);
            playerLabel.setBackground(new Color(124, 149, 222));
            double percentage;
            if(player.getSuccessfullAttacks()!=0 && players.get(1).getKilledPieces()!=0) {
                percentage = (double) players.get(0).getKilledPieces() / player.getSuccessfullAttacks();
            }else{
                percentage=0;
            }
            JLabel scoreLabel = new JLabel("---->  Percentage of successful attacks of player: "+ percentage);
            scoreLabel.setOpaque(true);
            scoreLabel.setBackground(Color.LIGHT_GRAY);

            JLabel round = new JLabel("---->  Round Number: "+controller.GetRound()); //+ controller get round
            round.setOpaque(true);
            round.setBackground(new Color(124, 149, 222));

            JLabel killedpieces = new JLabel("Total Killed Pieces : "+ player.getTotalKilledPieces().size());
            killedpieces.setOpaque(true);
            killedpieces.setBackground(Color.LIGHT_GRAY);

            menuPanel.add(Rules);
            menuPanel.add(mode);
            menuPanel.add(statistics);
            menuPanel.add(playerLabel);
            menuPanel.add(scoreLabel);
            menuPanel.add(round);
            menuPanel.add(killedpieces);

            changeVisibilityOfCards("Red");

            /*for(int i=0;i<player.getTotalKilledPieces().size();i++){
                colourCard="blue";
                cardname=player.getTotalKilledPieces().get(i).getName();
                ImageIcon imageIcon = getImageCard();
                JLabel icon = new JLabel(imageIcon);
                icons.add(icon);
            }*/

        }
    }

    /**
     * Method that changes the visibility of a players pieces depending on the turn of the player
     * @param colour1 is the colour of the cards we don't want to show
     */
    public void changeVisibilityOfCards(String colour1){

        for(int i=0;i<8;i++){
            for(int j=0;j<10;j++){
                b[i][j].setIcon(tempo[i][j].getIcon());
                b[i][j].setName(tempo[i][j].getName());
                if(pieces[i][j]!=null && pieces[i][j].getColour()==colour1){
                    col=colour1;
                    if(colour1=="Red"){
                        card="redHidden";

                    }else{
                        card="blueHidden";
                    }
                    b[i][j].setIcon(getImage());
                }
            }
        }
    }



}


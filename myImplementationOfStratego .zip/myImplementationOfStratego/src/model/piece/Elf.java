package model.piece;

public class Elf extends MovablePiece{
    public Elf(String colour,String name) {
        super(colour,name);
        setRank(4);
    }
}

package model.piece;

public class Slayer extends SpecialMovablePiece{
    public Slayer( String colour,String name) {
        super(colour,name);
        setRank(1);
    }

    /**
     * class Slayer overrides method attack because he has a special power and when he attacks a dragon he wins
     * @param piece2 the piece that defends
     */
    //@Override
    public void attack(Piece piece2) {
        super.attack(piece2);
        //if piece.getrank == 10
        //++ special power that kills the dragon
    }
}

package model.piece;

public abstract interface Piece {


    /**
     * Method that sets the name of the piece
     * @param name describes the name of the piece
     */
    public void setName(String name);

    /**
     * Method that returns the name of the piece
     * @return a string with the name of the piece
     */
    public String getName();

    /**
     * Method that initialises the rank of the piece
     * Pre-Condition: rank takes values from 0 to 10
     * @param rank the rank of the piece
     */
    public void setRank(int rank);

    /**
     * Method that returns the rank of the piece
     * @return the rank of the piece
     */
    public int getRank();

    /**
     * Method that sets the x coordination of the piece
     * @param x is x coordinator
     */
    public void setX(int x);

    /**
     * Method that returns the x coordination
     * @return the x coordination
     */
    public int getX();

    /**
     * Method that sets the y coordination
     * @param y is y coordination
     */
    public void setY(int y);

    /**
     * Method that returns the y coordination
     * @return the y coordination
     */
    public int getY();

    public void setColour(String colour);

    public String getColour();

}

package model.piece;

public class Dwarf extends SpecialMovablePiece{
    public Dwarf(String colour,String name) {
        super(colour,name);
        setRank(3);
    }

    /**
     * dwarf overrides attack method because it has a special power when it attacks traps
     * @param piece2 is the piece that is being attacked
     */
    public void attack(Piece piece2) {
        super.attack(piece2);
        //++ "kills" the trap
    }

}

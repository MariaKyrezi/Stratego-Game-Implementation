package model.piece;

public class Flag extends ImmovablePiece{

    public Flag(String colour,String name)
    {
        super(colour,name);
        super.setRank(0);
    }

}

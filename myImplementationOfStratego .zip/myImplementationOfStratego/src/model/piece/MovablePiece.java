package model.piece;

import model.board.Board;

public class MovablePiece implements Piece{
    private String name,colour;
    private int rank,x_coordinate,y_coordinate,numberOfKilledPieces, totalAttacks,count_saves;

    Piece[][] board= new Piece[8][10];
    Board b = new Board();
    /**
     * Constructor: Makes a new movable piece for the game with the given name and x, y coordinates
     */
    public MovablePiece(String colour,String name){
        setName(name);
        //setRank(rank);
        setColour(colour);
    }

    /**
     * Method that returns the number of attacks a piece has made
     * @return the total number of attacks the piece has made
     */
    public int getTotalAttacks(){
        return this.totalAttacks;
    }

    /**
     * Method that counts how many pieces of the same kind lost when attacked or defended themselves
     * @param numberOfKilledPieces is the number of "killed" pieces
     */
    public void setNumberOfKilledPieces(int numberOfKilledPieces){
        this.numberOfKilledPieces=numberOfKilledPieces;
    }
    /**
     * Method that returns the number of times the piece has been previously killed
     * @return the number of times the piece has been previously killed
     */
    public int getNumberOfKilledPieces(){
        return this.numberOfKilledPieces;
    }
    /**
     * Method that sets the number of saves the piece has made
     * pre-condition: the number has to be less than two
     * @param count_saves is the number of pieces the particular piece has saved
     */
    public void setCount_saves(int count_saves){
        this.count_saves=count_saves;
    }

    /**
     * Method that returns the number of saves the particular piece has made
     * post-condition: returns a number from 0 to 2
     * @return the number of saves the piece has made
     */
    public int getCount_saves(){
        return this.count_saves;
    }
    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setRank(int rank) {
        this.rank=rank;
    }

    @Override
    public int getRank() {
        return this.rank;
    }

    @Override
    public void setX(int x) {
        this.x_coordinate=x;
    }

    @Override
    public int getX() {
        return this.x_coordinate;
    }

    @Override
    public void setY(int y) {
        this.y_coordinate=y;
    }

    @Override
    public int getY() {
        return this.y_coordinate;
    }

    @Override
    public void setColour(String colour) {
        this.colour=colour;
    }

    @Override
    public String getColour() {
        return null;
    }

    /**
     * Transformer:
     * Method which makes a movable piece attack piece2
     * pre-condition: piece2 can be any type of piece, movable or immovable
     * @param piece2 the piece that defends
     */
    public void attack(Piece piece2){

    }

    /**
     * Transformer:
     * Method that moves the piece in the correct place on the board
     * @param x is the x coordinate the piece wants to move onto
     * @param y is the y coordinate the piece wants to move onto
     */

    public void move(int x, int y,int prevX, int prevY, Piece piece){
        b.setMovedPiece(x,y,prevX,prevY,piece);
    }

    /**
     * Accessor:
     * Method that checks if the piece can move in the place with x,y as coordinates
     * @param x next x coordinate of the piece
     * @param y next y coordinate of the piece
     * @return true or false if the piece can move in the wanted place or not based on the rules of the game
     */
    public boolean can_move(int x, int y,Piece piece){
        return false;//  to ftiaxnv argotera
    }

    /**
     * Transformer:
     * Method that returns a piece to the game that has been previously removed
     * @param piece1 the piece that is returned to the game
     * @return the piece that is returned to the game
     */
    public Piece save(Piece piece1){
        return null;
    }

    /**
     * Method that checks if the wanted piece can be saved and returned to the game
     * @param piece is the piece that the player wants to rescue
     * @return true or false if it's possible to rescue this piece
     */
    public boolean CanBeSaved(Piece piece){ return false;}


}

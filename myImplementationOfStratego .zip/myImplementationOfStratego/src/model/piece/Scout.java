package model.piece;

public class Scout extends SpecialMovablePiece {

    public Scout(String colour,String name) {
        super(colour,name);
        setRank(2);
    }

    /**
     * class Scout overrides method move because it has a special power with which it can move many empty spaces
     * @param x is the x coordinate the piece wants to move onto
     * @param y is the y coordinate the piece wants to move onto
     */
    public void move(int x, int y,int prevx, int prevy,Piece piece) {
        super.move(x, y,prevx,prevy,piece);
        //++ needs more special cases for the illustration of the special powers
    }

    /**
     * Method that overrides previously declared method because Scout can't save another piece
     * @param piece1 the piece that is returned to the game
     * @return null because Scout can't save any piece to put in the game
     */
    @Override
    public Piece save(Piece piece1) {
        return null;
    }
}

package model.piece;

public class BeastRider extends MovablePiece{

    public BeastRider(String colour,String name) {
        super(colour,name);
        setRank(7);
    }
}

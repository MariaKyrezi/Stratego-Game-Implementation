package model.piece;

public class Sorceress extends MovablePiece{
    public Sorceress(String colour,String name) {
        super(colour,name);
        setRank(6);
    }
}

package model.turn;

import model.player.BluePlayer;
import model.player.Player;

import java.util.ArrayList;

public class Turn {
    ArrayList<Player> players;
    private int round;
    private Player currentPlayer;
    private Player last_player;

    /** <b>Constructor</b>.
     * <b>Postcondition</b>Initialises the players with the decided choice of mode
     * 
     * @param choice is the choosen mode of the player for the game
     */
    public Turn(int choice)
    {
        //this.currentPlayer=new BluePlayer(choice);

        //this.last_player=new BluePlayer(choice);
    }

    /**
     * <b>Transformer(Mutative):</b> Sets the player's turn.(which player has the turn to play)
     * <b>Postcondition:</b> Player's turn has been set.
     * @param players is the list of players in the game (red player and blue player)
     */
    public void setPlayer(ArrayList <Player> players)
    {

    }

    /**
     * <b>Accessor(Selector):</b> returns the player's name whose turn is to play
     * <b>Postcondition:</b> returns the player's name whose turn is to play
     * @return the player's name whose turn is to play
     */
    public String getPlayer()
    {
        return this.currentPlayer.getName();
    }

    /**
     * <b>Observer:</b> Checks if a player has finished
     * <b>Postcondition:</b> returns true if a player has finished, else false
     * @param p is the player that we want to check if he finished his turn
     * @return true if a player has finished, else false
     */
    public boolean checkIfPlayerFinished(Player p)
    {
        return false;
    }

    /**
     * <b>Transformer(Mutative):</b> Sets the most recent player, who has moved a piece or attacked in the table.
     * <b>Postcondition:</b> The most recent player, who has moved a piece or attacked in the table has been set.
     * @param k is the player that played last
     */
    public void Set_last_player(Player k)
    {

    }

    /**
     * <b>Accessor(Selector):</b> returns the most recent player, who has moved a piece or attacked on the board
     * <b>Postcondition:</b> the most recent player, who has moved a piece or attacked in the table is returned
     * @return the most recent player, who has moved a piece or attacked in the table
     */
    public Player Get_last_player()
    {
        return this.last_player;
    }

    /**
     * A method that will push inside the arraylist the player that his turn finished and everytime we try to store
     * for a second time the first player that was pushed inside, the number of rounds will be added by 1.
     * @param players is the arraylist that holds the turn of players
     */
    public void countRounds(ArrayList<Player> players){

    }
}

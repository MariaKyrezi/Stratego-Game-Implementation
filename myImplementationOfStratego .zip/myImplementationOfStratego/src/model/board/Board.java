package model.board;

import model.piece.Piece;
import model.player.Player;

public class Board {

    /**
     * Make's a board following stratego's instructions that has 8 raws and 10 columns
     * This board has 30 pieces on each side for each player and also has some restricted areas.
     * The pieces cannot step on these restricted areas, so they are something like obstacles
     * @param player1 is the first player that plays the game
     * @param player2 is the person that plays stratego against player1
     */
    Piece[][] board;
    public Board(){
        board= new Piece[8][10];

    }

    /**
     * Method that puts the random pieces of a player on the board
     * @param board is the board of the game where all the pieces exist
     */
    public void putPiecesOnBoard(Piece[][] board){
        this.board=board;

    }

    public void setMovedPiece(int x, int y, int prevX,int prevY,Piece piece){
        this.board[x][y]=piece;
        this.board[prevX][prevY]=null;
    }

    public boolean canMove(int x, int y,Piece piece){
        if(board[x][y]!=null && board[x][y].getColour()==piece.getColour()){
            return false;
        }else{
            return true;
        }
    }
    /**
     * Method that makes the restricted areas of the board. Restricted areas are the places where pieces cannot move inside
     * @param board is the board of the game where all the pieces exist
     */
    public void RestrictedAreas(Piece[][] board){

    }

    /**
     * Method that adds the piece in a specific place on the board because another piece saved it
     * @param piece is a piece that has previously lost in an attack
     * @param x_coordinate is the x coordinate in which the piece will be put on the board
     * @param y_coordinate is the x coordinate in which the piece will be put on the board
     * @return the piece that has been added on the board in the specific place
     */
    public Piece addNewPieceOnBoard(Piece piece, int x_coordinate, int y_coordinate){
        return null;
    }

    /**
     * Method that removes a piece from the board after it has lost in an attack
     * @param piece is the piece that lost in the attack
     * @param board is the board of stratego where all the pieces exist
     */
    public void removePieceFromBoard(Piece piece, Piece[][] board){

    }

    /**
     * Method that checks the current position of the piece on the board and all the possible places it can move based on the mode that the player has chosen. These x,y coordinates are stored in an arrayList.
     * @param piece is the piece that we want to move on the board
     * @param board is the board of the stratego
     * @param player is the player that chooses the mode of the game.
     */
    public void possibleMovesOfPiece(Piece piece,Piece[][] board, Player player){

    }

}

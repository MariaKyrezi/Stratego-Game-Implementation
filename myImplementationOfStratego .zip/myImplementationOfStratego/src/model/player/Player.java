package model.player;

import model.piece.Piece;
import java.util.ArrayList;

public abstract interface Player {
    /**
     * Sets the name of the player
     * @param name the name of the player
     */
     public void setName(String name);

    /**
     * Method that returns the name of the player
     * @return the name of the player
     */
     public String getName();

    /**
     * Method that initializes the player with the correct pieces depending on his color / selected mode of the game
     */
     public void init_player();

    /**
     * <b>transformer(mutative)</b>: sets the collection of pieces that the player wants to play with  <br />
     * <p><b>Post-condition:</b> The collection of pieces of this player are being set</p>
     *
     */
    public void setPiecesforplaying();

    /**
     * Accessor(selector) : Returns an arraylist with the pieces of the player
     * @return the coolection of cards that the player has
     */
    public ArrayList<Piece> getPiecesForPlaying();

    /**
     * <b>transformer(mutative)</b>: adds a Piece to players pieces  <br />
     * <p><b>Post-condition:</b>  a piece added to players pieces</p>
     *
     * @param p the piece that will be added to players Collection
     *
     */
    //public void setPieces(Piece p);

    /**
     * Mode of the game in which the player starts with half of his pieces
     */
    public void ReducedArmy();

    /**
     * Mode of the game in which the player can not move his pieces backwards except when he wants to attack
     */
    public void NoRetreat();

    /**
     * <b>accessor(selector)</b>:Returns the choice of a player(ReducedArmy, NoRetreat, nothing or both) <br />
     *
     * <p><b>Postcondition:</b> Returns the choice of mode of a player </p>
     *
     * @return 0 if nothing, 1 if player choice is ReducedArmy, 2 if is NoRetreat and 3 if it is ReducedArmy and NoRetreat
     */
    public int getChoice();


    /**
     * <b>transformer(mutative)</b>: sets the variable hasplayed to true
     * <p><b>Postcondition:</b>  sets the variable hasplayed to true</p>
     */

    public void Played();


    /**
     * <b>transformer(mutative)</b>: Sets the variable has_finished to true
     * <p><b>Postcondition:</b>  sets the variable hasfinished to true</p>
     */
    //public void has_finished();

    /**
     * <b>Observer</b>:Returns if a player has played at least one time <br />
     *
     * <p><b>Postcondition:</b> Returns if a player has played at least one time </p>
     *
     * @return true if a player has played at least one time false otherwise
     */
    public boolean Has_Played();


    /**
     * <b>Observer</b>:Returns if a player has finished the game<br />
     *
     * <p><b>Postcondition:</b> Returns if a player has finished the game </p>
     *
     * @return true if a player has finished the game , false otherwise
     */
    //public boolean Get_has_finished();

    /**
     * Method that counts all the killed pieces of a player
     * @return the total number of killed pieces from the collection of the player
     */
    public int getTotalKilledPieces();//kanw override stous players

    /**
     * Method that counts from the collection of pieces the total number of attacks all the pieces have made and deducts the number of killed pieces
     * @return the total successfull attacks
     */
    public int getSuccessfullAttacks();

    public Piece returnRandomPiece();



}

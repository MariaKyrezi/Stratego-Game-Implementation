package controller;

import model.player.Player;
import model.turn.Turn;

import java.util.ArrayList;
import java.util.Collection;

public class Controller {
    int choice;
    private ArrayList <Player> players=new ArrayList<Player>();
    private Player RedPlayer, BluePlayer;
    private boolean notstarted;
    int round;



    /** <b>constructor</b>: Constructs a new Controller and sets the game as
     * ready to start .<br />
     * <b>postcondition</b>: constructs a new Controller,with 2 new players,new
     * instances of Turn Class and Collection Class and initializes the pieces of each player and
     * some int or boolean variables.So,is responsible for creating a new game and
     * initializing it.
     */
    Controller(){

    }
    /**
     * <b>transformer(mutative)</b>: initializes some things(the pieces,turn,round) for a new game
     * <p><b>Postcondition:</b>  initializes some things(the pieces,turn,round) for a new game</p>
     */
    public void init_board()
    {

    }
    /**
     * <b>transformer(mutative)</b>: initializes players' pieces in the beginning
     * <p><b>Postcondition:</b> initializes players' pieces in the beginning </p>
     */
    public void init_player_pieces()
    {

    }

    /**
     * <b>Observer</b>:Return true if a game has finished, false otherwise
     * <p><b>Post-condition:</b> return true if a game (one player won the flag,a player has only the flag and traps as pieces,
     * the traps are obstacles for the movement of the pieces)  has finished, false otherwise
     * </p>
     * @return true if a game has finished, false otherwise
     */
    public boolean game_has_finished()
    {
        return false;
    }

    /**
     * Method that changes the turn from one player to another
     */
    public void switchTurn(){

    }
    /**
     * Method that sets the number of round of the game
     * @param round
     */
    public void setRound(int round){
        this.round=round;
    }

    /**
     * Method that checks if the pieces of a player are only traps and the flag and returns true or false depending on that
     * @param player is the player whose pieces we want to check if they only have traps and the flag
     * @return true or false depending on the pieces that the player has
     */
    public boolean only_traps_flag(Player player){
        return false;
    }

    /**
     * <b>transformer(mutative)</b>: sets the variable not_started to false
     * <p><b>Postcondition:</b>  sets the variable not_started to false</p>
     */
    public void set_started()
    {
        this.notstarted=false;
    }


    /**
     *<b>Observer</b>: Return true if the game has not started  false otherwise
     * <p><b>Post-condition:</b> return true if the game  has not started  false otherwise
     * @return true if the game has not started  false otherwise
     */
    public boolean not_started()
    {
        return this.notstarted;
    }

    /**
     * <b>transformer(mutative)</b>: sets ReducedArmy for a player if a player push ReducedArmy button
     * <p><b>Postcondition:</b> sets ReducedArmy for a player if a player push ReducedArmy button </p>
     */
    public void setReducedArmy(){

    }

    /**
     * <b>transformer(mutative)</b>: sets NoRetreat for a player if a player push NoRetreat button
     * <p><b>Postcondition:</b> sets NoRetreat for a player if a player push NoRetreat button </p>
     */
    public void setNoRetreat(){

    }
    /**
     * <b>transformer(mutative)</b>: sets NoRetreat and ReducedArmy for a player if a player push Both button
     * <p><b>Postcondition:</b> sets NoRetreat and ReducedArmy for a player if a player push Both button </p>
     */
    public void setBoth(){

    }

    /**
     * <b>Transformer(mutative):</b>
     * <p><b>Post-condition:</b>sets as nothing the choice of the player for the mode of the game because player did not push any button</p>
     */
    public void setNothing(){

    }
    /**
     * <b>Observer</b>: Return true if we have a new round false otherwise.
     * This Method gets the size of the arraylist from the class turn and if it's an even number it begins a new round
     * <p><b>Postcondition:</b> return true if we have a new round false otherwise
     * </p>
     * @return true if we have a new round false otherwise
     */
    public boolean Get_new_round()
    {
        return true;
    }

    /**
     * Transformer : Makes the pieces of the player that is his turn to play visible and the other's backwards
     */
    public void changeVisibility(){

    }

    /**
     * Method that finds the winner of the game from the blue and red player
     * @return the winner of the game
     */
    public Player winner(){
        return null;
    }

}

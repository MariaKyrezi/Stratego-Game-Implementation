package view;

import model.board.Board;
import model.piece.Piece;
import model.piece.RestrictedArea;
import model.player.BluePlayer;
import model.player.Player;
import model.player.RedPlayer;
import model.turn.Turn;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import java.lang.Math;


public class View extends JFrame {
    //Player RedPlayer, BluePlayer;
    int choice,rank,prevx, prevy;
    //Menu menu= new Menu(turn);
    //JButton piecesRed[], piecesBlue[]; not needed because i made the arraylist of players
    ArrayList<Player> players = new ArrayList<>(2);
    Piece tempPiece;
    private JButton PlayButton,newGame,Exit;
    //JButton pieces[]=new JButton[60];not needed
    private boolean iconSelected;
    private JButton selectedButton;
    public String cardname="1",colourCard="2";
    Board board = new Board();
    Piece[][] pieces=new Piece[8][10];
    JButton[][] b=new JButton[8][10];
    /**
     * Constructor that makes a new window and puts buttons in the specific places where the pieces can move
     */
    public View(){
        initiateComponents();
        this.setTitle("Stratego graphics ");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        CardListener cl = new CardListener();
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 10));
        Board board =new Board();
        //JButton[][] b=new JButton[8][10];
        for (int i = 0; i < 8; i++) {
            for(int j = 0; j < 10 ; j++) {
                b[i][j] = new JButton();
                if (i <=2) {
                    pieces[i][j]=this.players.get(0).returnRandomPiece();
                    pieces[i][j].setX(i);
                    pieces[i][j].setY(j);
                    cardname=pieces[i][j].getName();
                    colourCard="Red";

                    b[i][j].setIcon(getImageCard());
                    b[i][j].setName(cardname);

                } else if ((i == 3 && j==2)||(i == 3 && j==3)||(i == 3 && j==6)||(i == 3 && j==7)||(i == 4 && j==2)||(i == 4 && j==3)||(i == 4 && j==6)||(i == 4 && j==7)) {
                    pieces[i][j]=new RestrictedArea();
                    pieces[i][j].setX(i);
                    pieces[i][j].setY(j);
                    b[i][j].setName("restricted");
                    b[i][j].setIcon(getImageRestricted());

                } else if(i>=5) {
                    colourCard="blue";
                    pieces[i][j]=this.players.get(1).returnRandomPiece();
                    pieces[i][j].setX(i);
                    pieces[i][j].setY(j);
                    cardname=pieces[i][j].getName();

                    b[i][j].setIcon(getImageCard());
                    b[i][j].setName(cardname);
                }else{
                    rank=0;
                    pieces[i][j]=null;
                    cardname="green";
                    b[i][j].setIcon(getImageBack());
                }

                b[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                b[i][j].addMouseListener(cl);
                panel.add(b[i][j]);
            }
        }
        board.putPiecesOnBoard(pieces);
        add(panel);
        iconSelected = false;

    }
    //CORRECT
    private ImageIcon getImageBack() { // image for background
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/green.jpg")));
            // return new ImageIcon(ImageIO.read(getClass().getResource("./images/RedPieces/dragonR.png"))); // image
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    //CORRECT
    private ImageIcon getImageRestricted() { // image for background
        try {
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/RestrictedArea.jpg")).getScaledInstance(90,80,Image.SCALE_SMOOTH));
            // return new ImageIcon(ImageIO.read(getClass().getResource("./images/RedPieces/dragonR.png"))); // image
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //CORRECT
    private ImageIcon getImageCard() { // image for card
        try {
            // System.out.println(getClass().getResource("./images/bluePieces/beastRiderB.png"));
            return new ImageIcon(ImageIO.read(getClass().getResource("/view/"+colourCard+"Pieces/"+cardname+".png"))
                    .getScaledInstance(90, 80, Image.SCALE_SMOOTH)); // image
        } catch (IOException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    private class CardListener implements MouseListener {
        @Override
        public void mouseClicked(MouseEvent e) {
            for(int i=0;i<8;i++){
                for(int j=0;j<10;j++){
                    if(b[i][j]==((JButton) e.getSource())){
                        JButton but = ((JButton) e.getSource());
                        //System.out.println(selectedButton.getName());
                        if (iconSelected && !but.equals(selectedButton) && but.getName()!="restricted") { // move(swap) buttons
                            //if(pieces[i][j].getName()=="dragon" && tempPiece.getName()=="slayer" && they dont have the same color
                            if ((Math.abs(tempPiece.getX() - i )<= 1 && Math.abs(tempPiece.getY() -j )< 1 ) || (Math.abs(tempPiece.getX() - i) < 1 && Math.abs(tempPiece.getY() -j )<= 1)){
                                if (pieces[i][j] == null || pieces[i][j].getRank() < rank) {
                                    but.setIcon(selectedButton.getIcon());
                                    but.setName(selectedButton.getName());
                                    but.setBorder(BorderFactory.createLineBorder(new Color(0, 115, 125), 5));
                                    selectedButton.setIcon(getImageBack());//here i have to fix what color it will return
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName("green");
                                    iconSelected = false;
                                    pieces[i][j] = tempPiece;
                                    pieces[i][j].setX(i);
                                    pieces[i][j].setY(j);
                                    pieces[i][j].setRank(tempPiece.getRank());
                                    pieces[prevx][prevy]=null;
                                    tempPiece=null;
                                    rank=0;

                                } else if (pieces[i][j].getRank() == rank){

                                    selectedButton.setIcon(getImageBack());
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName("green");

                                    but.setIcon(getImageBack());
                                    but.setBorder(BorderFactory.createLineBorder(Color.black));
                                    but.setName("green");

                                    iconSelected = false;
                                    pieces[i][j]=null;
                                    pieces[prevx][prevy]=null;
                                    tempPiece=null;
                                    rank=0;

                                }else{
                                    //but.setBorder(BorderFactory.createLineBorder(new Color(0, 115, 125), 5));
                                    selectedButton.setIcon(getImageBack());
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName("green");
                                    iconSelected = false;
                                    pieces[prevx][prevy]=null;
                                    rank=0;
                                    tempPiece=null;
                                }
                            }
                        } else if (!iconSelected && but.getName() != null && !but.getName().equals("restricted")&& but.getName()!="green") { // if not selected icon is joker then select
                            tempPiece=pieces[i][j];
                            tempPiece.setX(i);
                            tempPiece.setY(j);
                            prevx=i;
                            prevy=j;
                            rank=tempPiece.getRank();
                            iconSelected = true; // we can do without it, we can check for null selected button
                            selectedButton = but;
                            selectedButton.setIcon(but.getIcon());
                            but.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));

                        } else { // if already selected or not selected at all
                            //rank=pieces[i][j].getRank();
                            if (iconSelected) {
                                System.out.println("Already Selected");
                            } else {
                                System.out.println("Not selected");
                            }
                        }
                    }
                }
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    }

    /**
     * transformer(mutative) : Method that initializes some buttons and labels
     */
    private void initiateComponents(){
        players=new ArrayList<Player>(2);
        Player Red = new RedPlayer();
        Player Blue = new BluePlayer();
        players.add(Red);
        players.add(Blue);

    }
    public void moveButton(JButton selected, JButton current,Piece prev, Piece cur){
        if(prev.getRank()==3 && cur.getRank()==11){
            //the dwarf wins
            //current=selected;
        }else if(prev.getRank()==1 && cur.getRank()==10){
            //the slayer wins
        }
    }

    /**
     * Method that updates the collection of pieces the player has on display
     * @param player is the player that just played and maybe there are changes in his pieces
     */
    public void updatePlayerPieces(Player player) {
        player.getPiecesForPlaying();
    }

    /**
     * Method that updates the position of a piece on the display board after a movement or attack
     * @param piece is the piece that a player moved or made an attack with
     */
    public void updatePositionOfPiece(Piece piece){

    }

    /**
     * Method that updates the number of killed pieces in the menu display
     * @param player is the player that lost a piece after an attack
     */
    public void updateKilledPiecesOfPlayer(Player player){

    }

    /**
     * Method that updates the number of saved pieces of the specific player
     * @param player is the player whose piece was saved and put back in the game
     */
    public void updateSavedPiecesOfPlayer(Player player){

    }

    /**
     * Method that updated the number of round in the menu window
     * @param turn says whose player turn is to play
     * @param player is the player that is his turn to play
     */
    public void updateRoundNumber(Turn turn, Player player){

    }

    /**
     * Method that makes the restricted areas of the board
     */
    public void setRestrictedAreas(){

    }

    /**
     * Method that changes the visibility of a players pieces depending on the turn
     * @param turn is the variable that returns which player is to play
     * @param player is the player that we have to change the visibility of his cards
     */
    public void changeVisibilityOfCards(Turn turn, Player player){

    }

    /**
     * Method that returns to the game display a saved pieces from the player
     * @param x the x coordinate of the new piece on the display board
     * @param y the y coordinate of the new piece on the display board
     */
    public void RevivedPiecesDisplay(int x, int y){

    }

    /**
     * Method that removes from the display board the piece that was killed in an attack
     * @param piece is the piece that died
     * @param x is the x coordinate of the dead piece on the display board
     * @param y is the y coordinate of the dead piece on the display board
     */
    public void RemoveDeadPieces(Piece piece, int x,int y){

    }

    /**
     * It's an action listener which is used when a button of a place on the board apart from the restricted areas is pressed
     * */
    private class PiecesListener implements ActionListener {
        public void actionPerformed(ActionEvent e) 	{

        }
    }

    /**
     * It's an action listener which is used when a button is pressed and the game starts
     */
    private class PlayListener implements ActionListener 	{
        public void actionPerformed(ActionEvent e) 	{

        }
    }

    /**
     * It's an action listener which is used when a button is pressed and the player chooses the ReducedArmy as the mode of the round
     */
    private class ReducedArmyListener implements ActionListener{
        public void actionPerformed(ActionEvent e) 	{

        }
    }

    /**
     * It's an action listener which is used when a button is pressed and the player chooses the NoRetrreat as the mode of the round
     */
    private class NoRetreat implements ActionListener{
        public void actionPerformed(ActionEvent e) 	{

        }
    }
    /**
     * It's an action listener which is used when a button is pressed and the player chooses the NoRetrreat and ReducedArmy as mode of the round
     */
    private class BothModes implements ActionListener{
        public void actionPerformed(ActionEvent e) 	{

        }
    }

    /**
     * It's an action listener which is used when a button is not pressed and the player chooses nothing as the mode of the round
     */
    private class None implements ActionListener{
        public void actionPerformed(ActionEvent e) 	{

        }
    }

}


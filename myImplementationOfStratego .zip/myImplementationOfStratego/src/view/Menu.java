package view;

import model.turn.Turn;

public class Menu {
    int choice;

    /**
     * Constructor that makes a new window divided by 6 lines where in the first block will be written "Basic Instructions".
     * In the second block it will make 3 JButtons where each button will be a choice made by the player for the mode of the game (ReducedArmy,NoRetreat,Both)
     * The third block will have written the word "Statistics"
     * The forth block will have the player that is his turn to play, the number of round, the total saves and the percentage of successfull attacks
     * The fifth block will write "killed pieces"
     * Lastly, the sixth block will have written inside the total killed pieces of player and the images of each piece(from the 12 different ones) and the times they were killed
     * @param turn shows the player that is his turn to play
     */
    public Menu(Turn turn){

    }
    /**
     * Method that returns the choice of the player for the mode of the game
     * @return the integer that shows the choice of mode
     */
    public int getChoice(){
        return this.choice=choice;
    }
}

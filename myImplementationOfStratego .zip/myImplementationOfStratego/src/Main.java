import view.View;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        //MovePiece view = new MovePiece(); // create window (jframe)
        //Board table=new Board();

        View view = new View(); // create window (jframe)
        view.setSize(900, 700);
        //view.pack();
        view.setVisible(true);

    }
}
